using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine;

public class Mover : MonoBehaviour
{
    // The speed at which the object moves along the grid
    public float speed = 20f;
    float gridDistance = 1f;

    private MyMDP mdp;
    private QLearningSolver qLearningSolver;

    private int[] policy;
    bool canMove = true;
    bool start = false;
    bool useQLearning;

    private Vector2Int position;
    private int currentState;


    

    // Set up the mover using the MDP
    public void SetUp(MyMDP mdp, int[] policy)
    {
        this.mdp = mdp;
        this.policy = policy;

        useQLearning = false;

        // Get the starting position of the object
        int startState = mdp.GetState(Mathf.RoundToInt(transform.position.x), Mathf.RoundToInt(transform.position.y));
        position = new Vector2Int(mdp.GetX(startState), mdp.GetY(startState));

        start = true;
    }

    // Set up the mover using the QLearning
    public void SetUp(QLearningSolver qLearningSolver, int[] policy, int startState, float gridDistance)
    {
        this.qLearningSolver =  qLearningSolver;
        this.policy = policy;

        useQLearning = true;

        this.gridDistance = gridDistance;

        while(qLearningSolver.IsObstacleState(startState))
        {
            startState = UnityEngine.Random.Range(0, qLearningSolver.numStates); 
        }


        position = new Vector2Int(qLearningSolver.GetX(startState), qLearningSolver.GetY(startState));
        this.transform.position = new Vector3(position.x,position.y, 0.0f);

        start = true;
    }


    void Update()
    {   
        if(start == true)
        {
            if(useQLearning == false)
            {
                // Move the object according to the MDP policy
                int action = policy[mdp.GetState(position.x, position.y)];
                MoveObject(action);
            }
            else
            {
                // Move the object according to the qLearning policy
                int action = policy[qLearningSolver.GetState(position.x, position.y)];
                MoveObjectQ(action);
            }
        }
    }

    // Move the object in the given direction
    private void MoveObject(int action)
    {
        // Get the next position based on the action
        int nextState = mdp.GetNextState(position.x, position.y, action);
        int nextX = mdp.GetX(nextState);
        int nextY = mdp.GetY(nextState);

        // Move the object to the next position
        Vector2 nextPos = new Vector2(nextX, nextY);
        transform.position = Vector2.MoveTowards(transform.position, nextPos, speed * Time.deltaTime);

        // Pause the object for 0.3 seconds when it reaches the next position
        if ((Vector2)transform.position == nextPos && canMove == true)
        {
            canMove = false;
            StartCoroutine(PauseObject(nextX, nextY));
        }
    }

    // Coroutine to pause the object for 0.3 seconds
    private IEnumerator PauseObject(int nextX, int nextY)
    {
        Debug.Log("Reward = " + mdp.GetReward(nextX, nextY));
        yield return new WaitForSeconds(0.3f);

        // Update the current position of the object
        position = new Vector2Int(nextX, nextY);
        canMove = true;
    }


    // Move the object in the given direction
    private void MoveObjectQ(int action)
    {
        // Get the next position based on the action
        int nextState = qLearningSolver.GetNextState(position.x, position.y, action);
        int nextX = qLearningSolver.GetX(nextState);
        int nextY = qLearningSolver.GetY(nextState);

        // Move the object to the next position
        Vector2 nextPos = new Vector2(nextX * gridDistance, nextY * gridDistance);
        transform.position = Vector2.MoveTowards(transform.position, nextPos, speed * Time.deltaTime);

        // Pause the object for 0.3 seconds when it reaches the next position
        if ((Vector2)transform.position == nextPos && canMove == true)
        {
            canMove = false;
            StartCoroutine(PauseObjectQ(nextX, nextY));
        }
    }

    // Coroutine to pause the object for 0.3 seconds
    private IEnumerator PauseObjectQ(int nextX, int nextY)
    {
        Debug.Log("Reward = " + qLearningSolver.GetReward(nextX, nextY));
        yield return new WaitForSeconds(0.15f);

        // Update the current position of the object
        position = new Vector2Int(nextX, nextY);
        canMove = true;
    }
}
