using System.Collections;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using System;

public class QLearningSolver
{
    private int gridSize;
    public int numStates;
    private int numActions;
    private HashSet<int> obstacleStates;
    private float[,,] transitionProbs;
    private float[,,] rewards;
    private float[,] INPUT_REWARDS_TABLE;
    private float gamma;
    private float[,] qValues;
    private float alpha; // Learning rate
    private float epsilon; // Exploration rate
    private int obstacleReward = -1000;




    public List<int[]> policyList = new List<int[]>();
    public List<int> startingStateList = new List<int>();

    public QLearningSolver(int gridSize, float gamma, float[,] REWARDS, Vector2Int[] OBSTACLE_POSITIONS, float alpha, float epsilon)
    {
        this.gridSize = gridSize;
        numStates = gridSize * gridSize;
        numActions = 4; // up, down, left, right
        obstacleStates = new HashSet<int>();
        transitionProbs = new float[numStates, numActions, numStates];
        rewards = new float[numStates, numActions, numStates];
        this.gamma = gamma;
        INPUT_REWARDS_TABLE = REWARDS;

        // Initialize Q-values to zero
        qValues = new float[numStates, numActions];

        // Set learning rate and exploration rate
        this.alpha = alpha;
        this.epsilon = epsilon;

        foreach (Vector2Int obstacle in OBSTACLE_POSITIONS)
        {
            int state = GetState(obstacle.x, obstacle.y);
            SetObstacleState(state);
        }

        SetTransitionProbs();
        SetRewardsProbs();

    }

    public void SetTransitionProbs()
{
    // Initialize everything to 0
    for (int state = 0; state < numStates; state++)
    {
        for (int action = 0; action < numActions; action++)
        {
            for (int nextState = 0; nextState < numStates; nextState++)
            {
                transitionProbs[state, action, nextState] = 0f;
            }
        }
    }

    // Set the transition probabilities for each state-action pair
    for (int state = 0; state < numStates; state++)
    {
        int x = GetX(state);
        int y = GetY(state);

        // Check if the current state is an obstacle state
        if (IsObstacleState(state))
        {
            // If it is, set the transition probabilities to zero for all actions except staying in the same state
            for (int action = 0; action < numActions; action++)
            {
                int nextState = GetState(x, y);
                transitionProbs[state, action, nextState] = 1f / numActions;
            }
            continue;
        }

        // Set the transition probabilities for each action
        for (int action = 0; action < numActions; action++)
        {
            int nextX = x;
            int nextY = y;

            // Move up if it would not take out of grid boundaries
            if (action == 0 && y < gridSize - 1)
            {
                nextY += 1;
            }
            // Move down if it would not take out of grid boundaries
            else if (action == 1 && y > 0)
            {
                nextY -= 1;
            }
            // Move left if it would not take out of grid boundaries
            else if (action == 2 && x > 0)
            {
                nextX -= 1;
            }
            // Move right if it would not take out of grid boundaries
            else if (action == 3 && x < gridSize - 1)
            {
                nextX += 1;
            }

            int nextState = GetState(nextX, nextY);

            // Check if the movement would result in an obstacle or take the agent outside the grid
            if (IsObstacleState(nextState) || nextState == state)
            {
                // If it would, set the transition probability to stay in the same state
                transitionProbs[state, action, state] = 1f;
            }
            else
            {
                // Set the transition probability to move to the next state
                transitionProbs[state, action, nextState] = 1f;
            }
        }
    }
}

    public void SetRewardsProbs()
    {
        // Calculate the transition probabilities and rewards for each state-action pair
        for (int state = 0; state < GetNumStates(); state++)
        {
            for (int action = 0; action < GetNumActions(); action++)
            {
                //Get the next state and the corresponding probability
                (int nextState, float prob) = GetNextStateAndProb(state, action);

                //If the probability of transitioning to that state is greater than 0, then set the reward for that state action-pair

                if (prob > 0)
                {
                    float reward;

                    if (nextState == state)
                    {
                        //Debug.Log("Next State is obstacle");
                        reward = obstacleReward;
                    }
                    else//get the reward associated with the nextState
                    {
                        reward = INPUT_REWARDS_TABLE[(gridSize - 1) - GetY(nextState), GetX(nextState)];
                    }
          
                    Debug.Log($"State: {state}, StateX: {GetX(state)}, StateY: {GetY(state)}, NextState: {nextState}, StateX: {GetX(nextState)}, StateY: {GetY(nextState)}, Action: {action}, Reward: {reward}");
                    SetReward(state, action, reward);
                }
                else
                {
                    
                }
            }
        }
    }

    // Get the state ID for a given position on the grid
    public int GetState(int x, int y)
    {
        return x * gridSize + y;
    }

    // Set a state as an obstacle state
    public void SetObstacleState(int state)
    {
        obstacleStates.Add(state);
    }

    // Check if a state is an obstacle state
    public bool IsObstacleState(int state)
    {
        return obstacleStates.Contains(state);
    }

    // Get the number of states in the MDP
    public int GetNumStates()
    {
        return numStates;
    }

    // Get the number of actions in the MDP
    public int GetNumActions()
    {
        return numActions;
    }

    // Get the next state and the corresponding probability for a given state-action pair
    public (int, float) GetNextStateAndProb(int state, int action)
    {
        int x = GetX(state);
        int y = GetY(state);

        // Determine the next position based on the action
        int newX = x;
        int newY = y;

        if (action == 0) // up
        {
            newY += 1;
        }
        else if (action == 1) // down
        {
            newY -= 1;
        }
        else if (action == 2) // left
        {
            newX -= 1;
        }
        else if (action == 3) // right
        {
            newX += 1;
        }

        // Check if the next position is within the bounds of the grid
        if (newX < 0 || newX >= gridSize || newY < 0 || newY >= gridSize)
        {
            return (state, 1f); // stay in the same state with probability 1
        }

        // Get the next state ID
        int nextState = GetState(newX, newY);

        // Get the probability of transitioning to the next state
        float prob = transitionProbs[state, action, nextState];

        return (nextState, prob);
    }

    // Get the next state for a given state-action pair
    public int GetNextState(int x, int y, int action)
    {
        int nextX = x;
        int nextY = y;

        // Move up
        if (action == 0 && y < gridSize - 1)
        {
            nextY += 1;
        }
        // Move down
        else if (action == 1 && y > 0)
        {
            nextY -= 1;
        }
        // Move left
        else if (action == 2 && x > 0)
        {
            nextX -= 1;
        }
        // Move right
        else if (action == 3 && x < gridSize - 1)
        {
            nextX += 1;
        }

        int nextState = GetState(nextX, nextY);

        // If the next state is an obstacle state, stay in the current state
        if (IsObstacleState(nextState))
        {
            nextState = GetState(x, y);
        }

        return nextState;
    }

    // Get the x-coordinate of a state
    public int GetX(int state)
    {
        return state / gridSize;
    }

    // Get the y-coordinate of a state
    public int GetY(int state)
    {
        return state % gridSize;
    }

    public void SetReward(int state, int action, float reward)
    {
        rewards[state, action, GetNextState(GetX(state), GetY(state), action)] = reward;
    }

    public float GetReward(int x, int y)
    {
        if (x >= 0 && x < gridSize && y >= 0 && y < gridSize)
        {
            int state = GetState(x, y);
            float reward = 0f;
            for (int a = 0; a < numActions; a++)
            {
                for (int s = 0; s < numStates; s++)
                {
                    reward += GetTransitionProb(state, a, s) * rewards[state, a, s];
                }
            }
            return reward;
        }
        return float.MinValue; // Invalid reward
    }

    public float GetTransitionProb(int state, int action, int nextState)
    {
        return transitionProbs[state, action, nextState];
    }

    public int[] GetOptimalPolicy()
    {
        int[] policy = new int[GetNumStates()];

        // For each state, choose the action with the highest Q-value
        for (int state = 0; state < GetNumStates(); state++)
        {
            float maxQValue = float.MinValue;
            int maxAction = -1;

            for (int action = 0; action < GetNumActions(); action++)
            {
                if (qValues[state, action] > maxQValue)
                {
                    maxQValue = qValues[state, action];
                    maxAction = action;
                }
            }

            policy[state] = maxAction;
        }

        return policy;
    }

    public void QLearning(int numEpisodes, int maxIterations, int getPolicyOnEpisode)
    {
        for (int episode = 0; episode < numEpisodes; episode++)
        {
            int state = UnityEngine.Random.Range(0, numStates);

            while(IsObstacleState(state))
            {
                state = UnityEngine.Random.Range(0, numStates);
            }

            if (episode % getPolicyOnEpisode == 0)
            {
                startingStateList.Add(state);
            }

            int count = 0;
            while (count < maxIterations)
            {
                int action = ChooseAction(state);

                (int nextState, float reward) = GetNextStateAndReward(state, action);

                float maxQValue = GetMaxQValue(nextState);

                //update qValue using temporal difference error

                //qValues[state,action] is the current estimate of Q-values
                //alpha is learning rate
                //reward is the reward obtained by taking action in that state
                //gamma is the discount factor (imporatance of future rewards vs immediate rewards)
                //maxQValue is the maximum QValue amoung all possible actions in the next state.
                qValues[state, action] = qValues[state, action] + alpha * (reward + gamma * maxQValue - qValues[state, action]);

                state = nextState;

                if(reward == obstacleReward)
                {
                    Debug.Log("breaking");
                    break;
                }

                count++;
            }

            // Every xth episode, add the current policy to the list
            if (episode % getPolicyOnEpisode == 0)
            {
                int[] policy = GetOptimalPolicy();
                policyList.Add(policy);
            }

        }
    }

    private int ChooseAction(int state)
    {
        if (UnityEngine.Random.Range(0.0f, 1.0f) < epsilon)
        {
            // Choose a random action with probability epsilon
            return UnityEngine.Random.Range(0, numActions);
        }
        else
        {
            // Choose the action with the highest Q-value for the current state with probability 1-epsilon
            float[] qValuesForState = new float[numActions];
            for (int i = 0; i < numActions; i++)
            {
                qValuesForState[i] = qValues[state, i];
            }
            return Array.IndexOf(qValuesForState, qValuesForState.Max());
        }
    }

    private float GetMaxQValue(int state)
    {
        float maxQValue = float.MinValue;
        for (int i = 0; i < numActions; i++)
        {
            if (qValues[state, i] > maxQValue)
            {
                maxQValue = qValues[state, i];
            }
        }
        return maxQValue;
    }

    private (int, float) GetNextStateAndReward(int state, int action)
    {
        int nextState = GetNextState(state, action);

        if (nextState == -1)
        {
            Debug.Log("nextState = -1");
            return (state, obstacleReward);
        }
        else
        {
            float reward = rewards[state, action, nextState];
            return (GetNextState(state, action), reward);

        }
    }

    private int GetNextState(int state, int action)
    {
        float p = UnityEngine.Random.Range(0.0f, 1.0f);
        int nextState = -1;
        float cumulativeProbability = 0.0f;
        for (int s = 0; s < numStates; s++)
        {
            cumulativeProbability += transitionProbs[state, action, s];
            if (p <= cumulativeProbability)
            {
                nextState = s;
                break;
            }
        }

        //Debug.Log(nextState);
        return nextState;
    }
}
