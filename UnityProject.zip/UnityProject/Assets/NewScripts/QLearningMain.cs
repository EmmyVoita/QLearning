using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;


public class QLearningMain : MonoBehaviour
{
    public const int GRID_SIZE = 12;
    

    [Header("QLearning Main Properties:")]
    public float discountFactor = 0.99f;
    public float threshold = 0.001f;
    public float learningRate = 1.0f;
    public float explorationRate = 1.0f;
    [Space(10)]

    [Header("QLearning Episode Properties:")]
    public int numOfEpisodes = 1000;
    public int maxEpisodeIterations = 100;
    [Space(10)]

    [Header("Custom Iteration Properties:\n[x -> custom start state] \n[c -> random start state] \n[space -> next episode]")]
    public int getPolicyOnEpisode = 100;
    public Vector2Int customStartState = new Vector2Int(0,0);
    [Space(10)]

    [Header("References:")]
    public GameObject GridMarker;
    public float gridDistance = 2.0f;
    public GameObject MyTextObject;

    private int policyNum = 0;
    Mover mover;
    TextMeshProUGUI myText;

    


    private readonly Vector2Int[] OBSTACLE_POSITIONS = 
    {
        new Vector2Int(0, 2),
        new Vector2Int(2, 1),
        new Vector2Int(3, 3),
        new Vector2Int(6, 2),
        new Vector2Int(5, 5),
        new Vector2Int(9, 10),
        new Vector2Int(5, 10),
        new Vector2Int(6, 11)
    };

    public float[,] REWARDS = 
    {
        {0,  0, 0, -1, -1,  0, 0,  0, 0, -1, -1,  0},
        { -1, 4, 6, -100 , 7,  0, 0,  0, -5, 0, -1,  0},
        { 0, 1, 0, -1, -1,  -1, 0,  0, 0, 4, -1,  0},
        {-1, 0, 0, 0 ,0,  0, 0,  -2, -2, 4, -1,  0},
        { 0, 0, -1, 0 ,-1,  0, -2,  30, -2, 4, -1,  0},
        { 0, 0, 0, 0 ,0,  0, 0,  -2, -2, 4, -1,  0},
        {0,  0, 0, 4, -1,  0, 0,  0, 0, 4, -1,  0},
        { -1, 4, -5, -100 , 7,  0, 0,  0, 0, 4, -1,  0},
        { 0, 1, 0, -1, -1,  -1, -2,  0, 0, 4, -1,  0},
        {-1, 0, 0, 0 ,20,  0, -2,  -2, -2, 4, -1,  0},
        { 0, 0, -1, 0 ,-1,  0, 0,  0, 0, 4, -1,  0},
        { 0, 0, 0, 0 ,0,  0, 0,  0, 0, -3, -1,  0}
    };

    private QLearningSolver qLearningSolver;


    void Start()
    {
        myText = MyTextObject.GetComponent<TextMeshProUGUI>();
        mover = gameObject.GetComponent<Mover>();

        ShowGrid();

        //QLearning class
        qLearningSolver = new QLearningSolver(GRID_SIZE, discountFactor, REWARDS, OBSTACLE_POSITIONS, learningRate, explorationRate);
        qLearningSolver.QLearning(numOfEpisodes, maxEpisodeIterations, getPolicyOnEpisode);

    }

    void Update()
    {
        if (Input.GetKeyDown("space"))
        {
            
            Destroy(GetComponent<Mover>());
            mover = gameObject.AddComponent<Mover>();
            int[] policy = qLearningSolver.policyList[policyNum];
            mover.SetUp(qLearningSolver, policy, qLearningSolver.startingStateList[policyNum], gridDistance);
            policyNum++;
            myText.text = "Episode Number: " + policyNum * getPolicyOnEpisode;
        }

        if (Input.GetKeyDown("c"))
        {
            myText.text = "Episode Number: " + policyNum * getPolicyOnEpisode;
            Destroy(GetComponent<Mover>());
            mover = gameObject.AddComponent<Mover>();
            int[] policy = qLearningSolver.policyList[policyNum];
            mover.SetUp(qLearningSolver, policy, UnityEngine.Random.Range(0, qLearningSolver.numStates), gridDistance);
        }

        if (Input.GetKeyDown("x"))
        {
            myText.text = "Episode Number: " + policyNum * getPolicyOnEpisode;
            Destroy(GetComponent<Mover>());
            mover = gameObject.AddComponent<Mover>();
            int[] policy = qLearningSolver.policyList[policyNum];
            mover.SetUp(qLearningSolver, policy, qLearningSolver.GetState(customStartState.x, customStartState.y), gridDistance);
        }
    }


    void ShowGrid()
    {
        for (int i = 0; i < GRID_SIZE; i++)
        {
            for (int j = 0; j < GRID_SIZE; j++)
            {
                GameObject marker = Instantiate(GridMarker, new Vector2(i * gridDistance,j * gridDistance), Quaternion.identity);
                bool isObstacle = false;
                for (int k = 0; k < OBSTACLE_POSITIONS.Length; k++)
                { 
                    if(marker.transform.position * gridDistance == new Vector3(OBSTACLE_POSITIONS[k].x, OBSTACLE_POSITIONS[k].y,0))
                    {
                        marker.GetComponent<SpriteRenderer>().color = Color.red;
                        isObstacle = true;
                        break;
                    }
                }
                if (!isObstacle)
                {
                    if((REWARDS[(GRID_SIZE - 1) - j, i]) > 0)
                    {
                        marker.GetComponent<SpriteRenderer>().color = new Color(0, 0, (REWARDS[(GRID_SIZE - 1) - j, i]) * 0.1f, 255);
                    }
                    else
                    {
                        marker.GetComponent<SpriteRenderer>().color = new Color(0.5f, 0.5f, 0.5f, 50);
                    }
                    

                    marker.GetComponentInChildren<TextMeshPro>().text = REWARDS[(GRID_SIZE - 1) - j, i].ToString();
                }
            }
        }
    }

}

